package jpabook.jpashopPractice1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpashopPractice1Application {

	public static void main(String[] args) {
		SpringApplication.run(JpashopPractice1Application.class, args);
	}

}

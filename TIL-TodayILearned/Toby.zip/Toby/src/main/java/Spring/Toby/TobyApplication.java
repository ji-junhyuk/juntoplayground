package Spring.Toby;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TobyApplication {

	public static void main(String[] args) {
		SpringApplication.run(TobyApplication.class, args);
	}

}

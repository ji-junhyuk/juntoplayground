package hellospring.JPA1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jpa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}

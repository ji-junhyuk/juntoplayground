package jpashop.jpabook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpabookApplicationTests {

	@Test
	void contextLoads() {
	}

}
